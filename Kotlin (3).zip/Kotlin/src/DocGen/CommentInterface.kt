package DocGen

interface CommentInterface {
    var comment:ArrayList<Comment>
//    val lines : ArrayList<String>
//    var fun_line:String
//        get() = fun_line
}