//package java.io;
//public class Main{
//internal object HelloWorldKt {
//    @JvmStatic
//    fun main(args: Array<String>) {
//        println("Hello, World!")
//    }
//}

//
//public class Main {
//    fun  main() {
//        System.out.println("jj45j");
//    }
//}

object mai {
    @JvmStatic
    fun main(args: Array<String>) {
        println("jjkj")
    }
}


